# Search

The Search page shows a search box and list view for searching instances of `Item`.
